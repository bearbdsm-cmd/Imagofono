/**
 * BRIDGE.JS - Versión Multicanal
 */

const { Client } = require('node-osc');
const http = require('http');
const { Server } = require('socket.io');

// 1. Configuración de Sonic Pi (Puerto estándar: 4560)
const sonicPiClient = new Client('127.0.0.1', 4560);

const httpServer = http.createServer();
const io = new Server(httpServer, {
  cors: { origin: "*", methods: ["GET", "POST"] }
});

io.on('connection', (socket) => {
  console.log('✅ p5.js se ha conectado al puente');

  // Ahora 'data' será un objeto completo
  socket.on('message', (data) => {
    // Estructura esperada: { address: '/ruta', args: [val1, val2, val3...] }
    const { address, args } = data;
    
    if (address && args) {
      // Reenviamos TODO el arreglo de argumentos a Sonic Pi
      sonicPiClient.send(address, ...args, () => {
        // Opcional: loguear para debug (puedes comentarlo si hay mucho tráfico)
        // console.log(`📡 OSC: ${address} | Datos: ${args}`);
      });
    }
  });

  socket.on('disconnect', () => {
    console.log('❌ p5.js se ha desconectado');
  });
});

httpServer.listen(3333, () => {
  console.log('🚀 Puente OSC Multicanal activo en http://localhost:3333');
});