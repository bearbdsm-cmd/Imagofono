/**
 * Sketch para enviar mensajes OSC cada 2 segundos - CORREGIDO
 */

let socket; // <--- Declaramos la variable aquí arriba para que sea global
let lastSendTime = 0;
let i=0;
const interval = 2000; 

function setup() {
  createCanvas(400, 400);
  setupOsc(3333); 
  
  textAlign(CENTER, CENTER);
  textSize(16);
}

function draw() {
  background(220);
  
  if (millis() - lastSendTime > interval) {
    sendOscSignal();
    lastSendTime = millis();
  }

  text("Enviando señal OSC a Sonic Pi", width/2, height/2 - 20);
  if (millis() - lastSendTime < 200) {
    fill(255, 0, 0);
    ellipse(width/2, height/2 + 60, 20, 20);
  }
}

function sendOscSignal() {
  console.log("Señal enviada a las: " + hour() + ":" + minute() + ":" + second());
  sendOsc('/p5js/signal', i);
  i++;
}

/**
 * CONFIGURACIÓN OSC
 */
function setupOsc(oscPortIn) {
  // Usamos la IP directa y quitamos la restricción de transporte
  socket = io('http://127.0.0.1:3333');
  
  socket.on('connect', function() {
    console.log("✅ ¡CONECTADO! El puente está recibiendo datos.");
  });

  socket.on('connect_error', (error) => {
    console.error("Error de conexión:", error.message);
  });
}

function sendOsc(address, value) {
  if (socket && socket.connected) { // Verificación extra para evitar errores
    socket.emit('message', [address, value]);
  } else {
    console.warn("Socket no conectado aún...");
  }
}